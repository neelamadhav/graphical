This is a modified version of the Twitter Part-of-Speech Annotated Data (https://www.cs.purdue.edu/homes/dgoldwas/Teaching/ml4nlp/oct27.splits.zip)

============================================================================
  Data format:
    The "conll" format has one token per
    line, and a blank line to indicate a tweet boundary.  

    See the annotation guidelines, currently at:
    https://github.com/brendano/ark-tweet-nlp/blob/master/docs/annot_guidelines.md
============================================================================

Copyright (C) 2011-2012
Kevin Gimpel, Nathan Schneider, Brendan O'Connor, Dipanjan Das, Daniel
Mills, Jacob Eisenstein, Michael Heilman, Dani Yogatama, Jeffrey Flanigan,
and Noah A. Smith 
Language Technologies Institute, Carnegie Mellon University

This data is made available under the terms of the Creative Commons
Attribution 3.0 Unported license ("CC-BY"):
http://creativecommons.org/licenses/by/3.0/

